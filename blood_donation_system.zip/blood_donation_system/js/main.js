// ========== Helpers ==========
function saveData(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}
function loadData(key) {
  try {
    return JSON.parse(localStorage.getItem(key)) || [];
  } catch (e) {
    return [];
  }
}

// ========== Users Helper ==========
function loadUsers() {
  return loadData("users");
}
function saveUsers(users) {
  saveData("users", users);
}
function findUserByEmail(email) {
  const users = loadUsers();
  return users.find((u) => u.email === email);
}
function updateUserData(updatedUser) {
  let users = loadUsers();
  const idx = users.findIndex((u) => u.email === updatedUser.email);
  if (idx !== -1) {
    users[idx] = updatedUser;
    saveUsers(users);
  }
}

// ========== Current User ==========
function getCurrentUser() {
  try {
    return JSON.parse(localStorage.getItem("currentUser") || "null");
  } catch (e) {
    return null;
  }
}
function setCurrentUser(user) {
  localStorage.setItem("currentUser", JSON.stringify(user));
}

// ========== Auth ==========
function registerUser(name, email, password, blood) {
  let users = loadUsers();
  if (users.find((u) => u.email === email)) return false;
  users.push({ name, email, password, blood });
  saveUsers(users);
  return true;
}
function loginUser(email, password) {
  const users = loadUsers();
  const user = users.find((u) => u.email === email && u.password === password);
  if (user) {
    setCurrentUser(user);
    return true;
  }
  return false;
}

// ========== Data ==========
function getBloodStats() {
  const users = loadUsers();
  const groups = {
    "A+": 0,
    "A-": 0,
    "B+": 0,
    "B-": 0,
    "AB+": 0,
    "AB-": 0,
    "O+": 0,
    "O-": 0,
  };
  users.forEach((u) => {
    if (u.blood && groups[u.blood] !== undefined) groups[u.blood]++;
  });
  return groups;
}

function getNews() {
  return loadData("newsData").length
    ? loadData("newsData")
    : [
        {
          title: "Chiến dịch hiến máu mùa đông",
          date: "01/12/2025",
          content:
            "Kêu gọi hiến máu cứu người tại trung tâm thành phố. Hãy cùng chung tay!",
        },
        {
          title: "Ngày hội Hiến Máu Tình Nguyện",
          date: "15/12/2025",
          content: "Địa điểm: Nhà văn hóa - Tòa nhà A. Tham gia ngay hôm nay!",
        },
      ];
}

function saveScheduleRecord(email, date, place) {
  let records = loadData("schedules");
  records.push({ email, date, place });
  saveData("schedules", records);
}
function loadSchedules() {
  return loadData("schedules");
}

function saveEmergencyRecord(obj) {
  let arr = loadData("emergencies");
  arr.unshift(obj);
  saveData("emergencies", arr);
}
function loadEmergencies() {
  return loadData("emergencies");
}

// ========== Page Behavior ==========
document.addEventListener("DOMContentLoaded", () => {
  const currentUser = getCurrentUser();

  // Avatar dropdown
  const avatar = document.querySelector("#userAvatar");
  const dropdown = document.querySelector("#userDropdown");
  if (avatar && dropdown) {
    avatar.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdown.style.display =
        dropdown.style.display === "block" ? "none" : "block";
      if (currentUser) {
        dropdown.querySelector("#userNameTop").innerText = currentUser.name;
        dropdown.querySelector("#userEmailTop").innerText = currentUser.email;
      }
    });
    window.addEventListener("click", () => (dropdown.style.display = "none"));
  }

  // Logout
  const logoutBtns = document.querySelectorAll("#logoutTop, #logoutBtn");
  logoutBtns.forEach((btn) =>
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      localStorage.removeItem("currentUser");
      window.location = "login.html";
    })
  );

  // Edit info
  const editInfoBtns = document.querySelectorAll(
    "#editInfoTop, #editInfo, #editProfileBtn"
  );
  editInfoBtns.forEach((btn) =>
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      if (!currentUser) return alert("Chưa đăng nhập");
      const newName = prompt("Cập nhật họ tên:", currentUser.name);
      if (newName) {
        currentUser.name = newName;
        updateUserData(currentUser);
        setCurrentUser(currentUser);
        alert("Cập nhật thành công!");
        location.reload();
      }
    })
  );

  // Change password
  const changePassBtns = document.querySelectorAll(
    "#changePassTop, #changePassBtn"
  );
  changePassBtns.forEach((btn) =>
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      if (!currentUser) return alert("Chưa đăng nhập");
      const oldPass = prompt("Nhập mật khẩu cũ:");
      if (oldPass !== currentUser.password)
        return alert("Mật khẩu cũ không đúng");
      const newPass = prompt("Nhập mật khẩu mới:");
      if (newPass) {
        currentUser.password = newPass;
        updateUserData(currentUser);
        setCurrentUser(currentUser);
        alert("Đổi mật khẩu thành công!");
      }
    })
  );

  // Login/Register
  const btnLogin = document.getElementById("btnLogin");
  if (btnLogin && !btnLogin.dataset.bound) {
    btnLogin.dataset.bound = true;
    btnLogin.addEventListener("click", (e) => {
      e.preventDefault();
      const email = document.getElementById("loginEmail").value.trim();
      const pass = document.getElementById("loginPass").value.trim();
      if (loginUser(email, pass)) {
        window.location = "index.html";
      } else alert("Email hoặc mật khẩu không đúng");
    });
  }

  const btnReg = document.getElementById("btnRegister");
  if (btnReg && !btnReg.dataset.bound) {
    btnReg.dataset.bound = true;
    btnReg.addEventListener("click", (e) => {
      e.preventDefault();
      const name = document.getElementById("regName").value.trim();
      const email = document.getElementById("regEmail").value.trim();
      const pass = document.getElementById("regPass").value.trim();
      const blood = document.getElementById("regBlood").value;
      if (!name || !email || !pass || !blood)
        return alert("Nhập đầy đủ thông tin");
      if (registerUser(name, email, pass, blood)) {
        alert("Đăng ký thành công! Hãy đăng nhập để tiếp tục.");
        window.location = "login.html";
      } else alert("Email đã tồn tại");
    });
  }

  // Render donors list
  const donorsTbody = document.querySelector("#donorsTable tbody");
  if (donorsTbody) {
    const users = loadUsers();
    donorsTbody.innerHTML = "";
    users.forEach((u) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${u.name}</td><td>${u.email}</td><td>${u.blood}</td>`;
      donorsTbody.appendChild(tr);
    });
  }

  // Render stats
  const bloodStatsBody = document.getElementById("bloodStatsBody");
  if (bloodStatsBody) {
    const stats = getBloodStats();
    bloodStatsBody.innerHTML = "";
    for (const g in stats) {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${g}</td><td>${stats[g]}</td>`;
      bloodStatsBody.appendChild(tr);
    }
  }

  // Render emergency list
  const emergencyList = document.getElementById("emergencyList");
  if (emergencyList) {
    const arr = loadEmergencies();
    emergencyList.innerHTML = "";
    arr.forEach((e) => {
      const div = document.createElement("div");
      div.className = "card small";
      div.innerHTML = `<strong>${e.name}</strong><div class="muted">${e.time}</div><p>${e.message}</p>`;
      emergencyList.appendChild(div);
    });
  }

  // Render news
  const newsList = document.getElementById("newsList");
  if (newsList) {
    const news = getNews();
    newsList.innerHTML = "";
    news.forEach((n) => {
      const item = document.createElement("div");
      item.className = "news-item";
      item.innerHTML = `<h3>${n.title}</h3><div class="muted">${n.date}</div><p>${n.content}</p>`;
      newsList.appendChild(item);
    });
  }

  // Render dashboard counts
  const totalDonorsEl = document.getElementById("totalDonors");
  const totalSchedulesEl = document.getElementById("totalSchedules");
  const totalEmergEl = document.getElementById("totalEmergencies");
  const newsCountEl = document.getElementById("newsCount");
  if (totalDonorsEl) {
    totalDonorsEl.innerText = loadUsers().length;
    totalSchedulesEl.innerText = loadSchedules().length;
    totalEmergEl.innerText = loadEmergencies().length;
    newsCountEl.innerText = getNews().length;
  }
});
